<?php include("expense-manager-menu.php"); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="jarviswidget-color-purple" id="">
				<span class="icon-input-btn">
					<span class="fa fa-plus"></span>
					<input type="button" name="expense-manager-add-group" class="btn btn-default btn-xs" id="expense-manager-add-group" value="Add New" />
				</span>
			</div>
			<div class="jarviswidget jarviswidget-color-purple" id="wid-id-0" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false">
				<div class="portlet box blue group">
					<div class="portlet-title">
						<div class="caption"><i class="fa fa-users"></i>List of Group</div>
					</div>
					<div class="portlet-body">
				        <div class="col-md-12">
							<table class="table table-hover">
								<thead class=table-head>
									<tr>
										<th>S.No</th>
										<th>Group</th>
										<th>Name</th>
										<th>Type</th>
										<th>Opening Balance</th>
										<th>Closing Balance</th>
									</tr>
								</thead>
								<tbody>
									<tr id="row102">
										<td>001</td>
										<td>Assets</td>
										<td>Large Assets</td>
										<td>Ledger</td>
										<td>5,84,0000</td>
										<td>87,59,54,90,000</td>
									</tr>
								</tbody>
						    </table>
				        </div>
					</div>
				</div>
			</div>
		</article>
	</div>	
</section>