<?php include("expense-manager-menu.php"); ?>
<?php $expenseManagerReports = array( 'balance-sheet' => 'Balance Sheet', 'profit-loss' => 'Profit Loss', 'trial-balance' => 'Trial Balance', 'ledger-statement' => 'Ledger Statement' ); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="jarviswidget jarviswidget-color-purple" id="wid-id-0" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false">
				<div class="portlet box blue report">
					<div class="portlet-title">
						<div class="caption"><i class="fa fa-bar-chart "></i><?php echo $expenseManagerReports[$_REQUEST['type']]; ?></div>
					</div>
					
					<div class="portlet-body">
				        <div class="col-md-12">
				        	
				        </div>
					</div>
				</div>
			</div>
		</article>
	</div>	
</section>