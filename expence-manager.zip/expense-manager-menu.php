<?php $expenseManagerPage = $this->ExpenseManagerGetPerameter(); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="widget-body well">
				<ul class="bs-glyphicons">
					<a href="?page=expense-manager">
					<li class="<?php if($expenseManagerPage=='manager'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-home"></span>
						<span class="glyphicon-class">DASHBOARD</span>
					</li>
					<a href="?page=expense-manager-groups">
					<li class="<?php if($expenseManagerPage=='groups'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-tags"></span>
						<span class="glyphicon-class">GROUP</span>
					</li>
					</a>
					<a href="?page=expense-manager-accounts">
					<li class="<?php if($expenseManagerPage=='accounts'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-book"></span>
						<span class="glyphicon-class">ACCOUNTS</span>
					</li>
					</a>
					<a href="?page=expense-manager-entries">
					<li class="<?php if($expenseManagerPage=='entries'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-list-alt"></span>
						<span class="glyphicon-class">ENTRIES</span>
					</li>
					</a>
					<a href="?page=expense-manager-reports">
					<li class="<?php if($expenseManagerPage=='reports'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-stats"></span>
						<span class="glyphicon-class">REPORTS</span>
					</li>
					</a>
					<a href="?page=expense-manager-settings">
					<li class="<?php if($expenseManagerPage=='settings'){ echo 'active'; } ?>">
						<span class="glyphicon glyphicon-wrench"></span>
						<span class="glyphicon-class">SETTINGS</span>
					</li>
					</a>
				</ul>
			</div>
		</article>
	</div>	
</section>