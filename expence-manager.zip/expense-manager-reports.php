<?php include("expense-manager-menu.php"); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="jarviswidget jarviswidget-color-purple" id="wid-id-0" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false">
				<div class="portlet box blue report">
					<div class="portlet-title">
						<div class="caption"><i class="fa fa-bar-chart "></i>List of Reports</div>
					</div>
					<?php $expenseManagerReports = array( 'balance-sheet' => 'Balance Sheet', 'profit-loss' => 'Profit Loss', 'trial-balance' => 'Trial Balance', 'ledger-statement' => 'Ledger Statement' ); ?>
					<div class="portlet-body">
				        <div class="col-md-12">
							<table class="table table-hover">
								<thead class=table-head>
									<tr>
										<th>No</th>
										<th>Report Name</th>
										<th>Type</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php $expenceManagerReportCounter = 1; foreach( $expenseManagerReports as $key=>$report ) : ?>
									<tr id="row102">
										<td><?php echo $expenceManagerReportCounter; ?></td>
										<td><?php echo $report; ?></td>
										<td><?php echo $key; ?></td>
										<td>
											<!-- <span class="icon-input-btn">
												<span class="fa fa-eye"></span>
												<input type="button" name="expense-manager-add-group" class="btn btn-default btn-xs edit-button" id="expense-manager-add-group" value="" />
											</span> -->
											<a href="?page=expense-manager-report&amp;type=<?php echo $key; ?>" class="btn btn-default btn-xs edit-button"> <span class="fa fa-eye"></span>View </a>
										</td></tr>
									</tr>
								<?php $expenceManagerReportCounter++; endforeach; ?>
								</tbody>
						    </table>
				        </div>
					</div>
				</div>
			</div>
		</article>
	</div>	
</section>