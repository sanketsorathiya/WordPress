<?php
/*
* Plugin Name: Expense Manager
* Plugin URI: http://sanket.nature.com/
* Description: ExpenseManager is Dealy Rutin Expene All The manage 
* Version: 1.0
* Author: Sanket Sorathiya
* Author URI: https://sanket.nature.com/
* Text Domain: expense-manager
* Domain Path: /languages
* License: GPLv3 or later
* License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

Class ExpenseManager {

	// Register INIT Expense Manager
	public function __construct() {
		add_action( 'admin_menu', array(&$this, 'ExpenseManagerMenu') );
		add_action( 'admin_enqueue_scripts', array(&$this, 'ExpenseManagerAssets') );
		add_action( 'init', array(&$this, 'ExpenseManagerTextDomain') );
		//add_action( 'admin_init', array(&$this, 'ExpenseManagerSettings' ) );
	}

	/*
	* Text Domain 
	*/
	public function ExpenseManagerTextDomain() {
		load_plugin_textdomain( 'expense-manager', false, basename( dirname( __FILE__ ) ) . '/languages' );
	}

	/*
	* Assets File 
	*/
	public function ExpenseManagerAssets() {
		wp_enqueue_style( 'bootstrap-min-css', plugins_url('assets/css/bootstrap.min.css', __FILE__),array(), '3.2.0' );
		wp_enqueue_style( 'font-awesome-css', plugins_url('assets/css/font-awesome.min.css', __FILE__),array(), '3.2.0' );
		wp_enqueue_style( 'smartadmin-production-min-css', plugins_url('assets/css/smartadmin-production.min.css', __FILE__),array(), '3.2.0' );
		wp_enqueue_style( 'smartadmin-skins-min-css', plugins_url('assets/css/smartadmin-skins.min.css', __FILE__),array(), '3.2.0' );
		wp_enqueue_style( 'kernel-css', plugins_url('assets/css/kernel.css', __FILE__),array(), '3.2.0' );
		wp_enqueue_style( 'expense-manager-css', plugins_url('assets/css/expense-manager.css', __FILE__), array() );
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'bootstrap-min-js', plugins_url('assets/js/bootstrap.min.js', __FILE__),array(), '3.1.1' );
		wp_enqueue_script( 'bootstrap-min-js', plugins_url('assets/js/jquery-ui.min.js', __FILE__),array(), '3.1.1' );
		wp_enqueue_script( 'bootstrap-min-js', plugins_url('assets/js/SmartNotification.min.js', __FILE__),array(), '3.1.1' );
		wp_enqueue_script( 'bootstrap-min-js', plugins_url('assets/js/jquery.easy-pie-chart.min.js', __FILE__),array(), '3.1.1' );		
	}

	/*
	* Menu
	*/
	public function ExpenseManagerMenu() {
		add_menu_page('Expense Manager', 'Expense Manager', 'manage_options', 'expense-manager', array(&$this,'ExpenseManagerDashBoard'), '');
		add_submenu_page('expense-manager', 'Dashboard', 'Dashboard', 'manage_options', 'expense-manager');
		add_submenu_page( 'expense-manager', 'Groups', 'Groups', 'manage_options', 'expense-manager-groups', array(&$this, 'ExpenseManagerGroups') );
		add_submenu_page( 'expense-manager', 'Accounts', 'Accounts', 'manage_options', 'expense-manager-accounts', array(&$this, 'ExpenseManagerAccounts') );
		add_submenu_page( 'expense-manager', 'Entries', 'Entries', 'manage_options', 'expense-manager-entries', array(&$this, 'ExpenseManagerEntries') );
		add_submenu_page( 'expense-manager', 'Reports', 'Reports', 'manage_options', 'expense-manager-reports', array(&$this, 'ExpenseManagerReports') );
		add_submenu_page( 'expense-manager', 'Settings', 'Settings', 'manage_options', 'expense-manager-settings', array(&$this, 'ExpenseManagerSettings') );
		add_submenu_page( 'expense-manager', 'Settings', 'Settings', 'manage_options', 'expense-manager-settings', array(&$this, 'ExpenseManagerSettings') );
		add_submenu_page( 'expense-manager', '', '', 'manage_options', 'expense-manager-report', array(&$this, 'ExpenseManagerReport') );
	}

	/* Callback Part **/
	public function ExpenseManagerDashBoard() {
		include("expense-manager-dashboard.php");
	}

	public function ExpenseManagerGroups() {
		include("expense-manager-groups.php");
	}

	public function ExpenseManagerAccounts() {
		include("expense-manager-accounts.php");
	}

	public function ExpenseManagerEntries() {
		include("expense-manager-entries.php");
	}

	public function ExpenseManagerReports() {
		include("expense-manager-reports.php");
	}

	public function ExpenseManagerSettings() {
		include("expense-manager-settings.php");
	}

	public function ExpenseManagerGetPerameter() {
		$expenseManagerCurrentScreens = get_current_screen(); 
		$pageArray = explode('-', $expenseManagerCurrentScreens->id);
		return  array_pop($pageArray);
	}

	public function ExpenseManagerReport() {
		//echo "<pre>"; print_r($_REQUEST); exit;
		include("expense-manager-report-view.php");
	}
}

$expenceManager = new ExpenseManager();
?>