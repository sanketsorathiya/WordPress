<?php include("expense-manager-menu.php"); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-6">
			<div class="jarviswidget well" id="wid-id-0a" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false" data-widget-sortable="false">
				<div class="expense-manager-dashboard-head-msg">
					<h1>Welcome Sanket Sorathiya</h1>
					<p>Account Year : 01 April 2016 - 31 March 2017</p>
				</div>
			</div>
		</article>
		<article class="col-sm-6">
			<div class="jarviswidget well" id="wid-id-0a" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false" data-widget-sortable="false">
				<div class="expense-manager-dashboard-head-msg">
					<p>Bank Cash :-<b>1500,00,000</b></p>
					<p>Cash On Hand :- <b>3500,00,000</b></p>
				</div>
			</div>
		</article>
	</div>
	<div class="row">
		<article class="col-sm-6">
			<div class="jarviswidget well" id="wid-id-0a" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false" data-widget-sortable="false">
				<div class="expense-manager-dashboard-head-msg">
					<h1></h1>
					<p></p>
					
				</div>
			</div>
		</article>
	</div>	
</section>