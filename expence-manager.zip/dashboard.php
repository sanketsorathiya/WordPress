<style>
	.bs-glyphicons {
		padding-left: 0;
		padding-bottom: 1px;
		margin-bottom: 20px;
		list-style: none;
		overflow: hidden;
	}
	.bs-glyphicons li {
		float: left;
		width: 25%;
		height: 115px;
		padding: 10px;
		margin: 0 -1px -1px 0;
		font-size: 12px;
		line-height: 1.4;
		text-align: center;
		border: 1px solid #ddd;
	}
	.bs-glyphicons .glyphicon {
		margin-top: 5px;
		margin-bottom: 10px;
		font-size: 24px;
	}
	.bs-glyphicons .glyphicon-class {
		display: block;
		text-align: center;
	}
	.bs-glyphicons li:hover {
		background-color: rgba(86,61,124,.1);
	}

	@media (min-width: 768px) {
		.bs-glyphicons li {
			width: 12.5%;
		}
	}

</style>
<div class="row">
	<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
		<h1 class="page-title txt-color-blueDark"><i class="fa-fw fa fa-home"></i> Dashboard </h1>
	</div>
</div>
<!-- widget grid -->
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<article class="col-sm-12">
			<div class="jarviswidget well" id="wid-id-0a" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false" data-widget-sortable="false">
				<div class="widget-body">
					<h1>Welcome to Chitoi CMS - Admin Panel</h1>
					<p>Select the actions from the Menu /List.</p>
				</div>
			</div>
		</article>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="jarviswidget jarviswidget-color-purple" id="wid-id-0" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false">
				<header>
					<h2>Options </h2>
				</header>
				<div>

					<div class="widget-body">
						<ul class="bs-glyphicons">
							<a href="#jobs/open">
							<li>
								<span class="glyphicon glyphicon-th-list"></span>
								<span class="glyphicon-class">Open Jobs</span>
							</li>
							<a href="#jobs/accepted">
							<li>
								<span class="glyphicon glyphicon-send"></span>
								<span class="glyphicon-class">Accepted Jobs</span>
							</li>
							</a>
							<a href="#jobs/completed">
							<li>
								<span class="glyphicon glyphicon-tower"></span>
								<span class="glyphicon-class">Completed Jobs</span>
							</li>
							</a>
							</a>
							<a href="#pages">
							<li>
								<span class="glyphicon glyphicon-asterisk"></span>
								<span class="glyphicon-class">Pages</span>
							</li>
							</a>
							<a href="#news">
							<li>
								<span class="glyphicon glyphicon-random"></span>
								<span class="glyphicon-class">News</span>
							</li>
							</a>
							<a href="#faqs">
							<li>
								<span class="glyphicon glyphicon-edit"></span>
								<span class="glyphicon-class">FAQs</span>
							</li>
							</a>
							<a href="#feedback">
							<li>
								<span class="glyphicon glyphicon-wrench"></span>
								<span class="glyphicon-class">Feedback</span>
							</li>
							</a>
						</ul>

					</div>
				</div>
			</div>
		</article>
	</div>	
</section>