<?php include("expense-manager-menu.php"); ?>
<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<div class="col-sm-12"> </div>
	</div>
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-sm-12">
			<div class="jarviswidget-color-purple" id="">
				<span class="icon-input-btn"><span class="fa fa-plus"></span><input type="button" name="expense-manager-add-group" class="btn btn-default btn-xs" id="expense-manager-add-group" value="Add New" /></span>
			</div>
			<div class="jarviswidget jarviswidget-color-purple" id="wid-id-0" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false">
				<div class="portlet box blue entries">
					<div class="portlet-title">
						<div class="caption"><i class="fa fa-list"></i>List of Entries Summary</div>
					</div>
					<div class="portlet-body">
					        <div class="col-md-12">
								<table class="table table-hover">
									<thead class=table-head>
										<tr>
											<th>Date</th>
											<th>No</th>
											<th>Account</th>
											<th>Type</th>
											<th>Dr Amount</th>
											<th>Cr Amount</th>
										</tr>
									</thead>
									<tbody>
										<tr id="row102">
											<td>20 Aug 2016</td>
											<td>001</td>
											<td>RAJU BHAI</td>
											<td>INCOME</td>
											<td>-</td>
											<td>87,59,54,90,000</td>
										</tr>
									</tbody>
							    </table>
					        </div>
					</div>
				</div>
			</div>
		</article>
	</div>	
</section>